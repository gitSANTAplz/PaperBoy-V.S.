package baseGame;

import java.util.Random;

public class Main {

	private Random spawnLogic = new Random();
	public int spawnOrder[] = new int[15];
	
	public void main(String[] args) { 
		for(int i = 0; i < 15; i++) {
			spawnOrder[i] = spawnLogic.nextInt();
		}
		GameScreen Play = new GameScreen();
	}
}
