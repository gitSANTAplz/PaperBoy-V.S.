package baseGame;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class GameScreen extends JFrame {
	public boolean p1left = false;
    public boolean p1up = false;
    public boolean p1down = false;
    public boolean p1right = false;
    public boolean p1toss = false;
    
    public boolean p2left = false;
    public boolean p2up = false;
    public boolean p2down = false;
    public boolean p2right = false;
    public boolean p2toss = false;
    
    public boolean selection1 = false;
    
    public JLabel Player1 = new JLabel();
    public JLabel Player2 = new JLabel();
    
    public GameScreen() {
    	setSize(1620,1000);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        
        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) p2left = false;
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) p2right = false;
                if (e.getKeyCode() == KeyEvent.VK_UP) p2up = false;
                if (e.getKeyCode() == KeyEvent.VK_DOWN) p2down = false;
            }
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) p2left = true;
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) p2right = true;
                if (e.getKeyCode() == KeyEvent.VK_UP) p2up = true;
                if (e.getKeyCode() == KeyEvent.VK_DOWN) p2down = true;
            }
        });
        
    }
}
